export type Lecture = {
  nid: string,
  nama_lengkap: string,
  alamat: string,
  telepon: string,
  tanggal_lahir: Date,
}
