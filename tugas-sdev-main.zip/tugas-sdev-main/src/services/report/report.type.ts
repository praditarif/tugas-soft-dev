export type Report = {
  nilai: number,
  id_mahasiswa: string,
  id_mata_kuliah: string
}
