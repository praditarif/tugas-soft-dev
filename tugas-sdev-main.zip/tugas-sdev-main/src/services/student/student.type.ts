export type Student = {
  nrp: string,
  nama_lengkap: string,
  alamat: string,
  telepon: string,
  tanggal_lahir: Date,
  id_kelas: string,
}
