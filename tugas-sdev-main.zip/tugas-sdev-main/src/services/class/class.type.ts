export type Class = {
  tahun: string,
  id_wali: string,
}