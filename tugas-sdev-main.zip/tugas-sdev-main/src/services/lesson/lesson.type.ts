export type Lesson = {
  kdmk: string,
  judul: string,
  sks: number,
  id_pengampu: string,
  id_kelas: string
}
